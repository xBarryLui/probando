import flet as ft
from flet import *
from cryptography.fernet import Fernet
from sql_module import SQL_MODULE


lst_colores = ["#2e8d7d", #Verde esmeralda 0
                   "#1d1c28", #Azul oscuro     1
                   "#3a3b47", #Gris claro      2
                   "#29323d", #Verde esmeralda oscuro     3
                   "white",   #Blanco color    4
                   "black",   #Negro color     5
                   "#2e2c3f",  #Gris oscuro    6
                   "#A0A0A0"  #Blanco apagado  7
                   ]
key = b"652OQj1DO5t6LONCHO-X1jN-XgthFVg60kmy3saP7sI="
def encriptar(texto):
    fernet = Fernet(key)
    return fernet.encrypt(texto.encode())
def desencriptar(texto):
    fernet = Fernet(key)
    return fernet.decrypt(texto).decode()

class Login(UserControl):
    #Variables 
    def __init__(self,page):
        super().__init__()
        self.page = page
        self.msg_rpta = ""
        #controles    
        self.btn_login_salir = ElevatedButton(content=Text("Salir",size=20,color=lst_colores[4]),width= 300,
                                            bgcolor=lst_colores[2],on_click=self.salir)
        self.btn_login_ingresar = ElevatedButton(content=Text("Ingresar",size=20,color=lst_colores[5]),width= 300,
                                            bgcolor=lst_colores[0],on_click=self.ingresar)
        self.txt_login_pass = TextField(value="",hint_text="Ingrese su contraseña",hint_style={"size":18,"color":"#A0A0A0"},width=300,
                                    text_size="18",color=lst_colores[4],border="none",bgcolor="transparent",
                                    prefix_icon=ft.icons.KEY,password=True,can_reveal_password=True)
        self.txt_login_pass_box = Container(width=300,height=40,border=border.only(bottom=BorderSide(0.5,"#2e8d7d")),
                                    content=self.txt_login_pass)
        self.bg_principal = Container(
                #Contenedor madre
                bgcolor= lst_colores[1],            
                height= 700,
                width= 500,
                border_radius=10,
                border=border.all(width=5,color=lst_colores[0]),
                content= Column(
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,spacing=0,
                    controls=[
                        Divider(color="transparent",height=45),
                        Icon(name=icons.ACCOUNT_CIRCLE,size=75),
                        Text("Iniciar Sesion",size=35,weight=ft.FontWeight.W_400,color="white"),
                        Divider(color="transparent",height=15),
                        Text(f"Bienvenido Leoncio Vasquez.",size=20,weight=ft.FontWeight.W_400,color="white"),
                        Divider(color="transparent",height=10),
                        self.txt_login_pass_box,Divider(color="transparent",height=15),
                        self.btn_login_ingresar,self.btn_login_salir,
                        Divider(color="transparent",height=250),
                        Image(src=f"/MyLogoLS.png",width=350,height=35),                    
                        Text("LUSOM Systems S.A.C",size=10,weight=ft.FontWeight.W_400,color=lst_colores[4])
                    ]
                )
        ) 

    def ingresar(self,e):
        self.txt_login_pass.value = str(SQL_MODULE.con())
        obt = SQL_MODULE.SQL_Consulta("Aux","id","=","1","id","ASC")
        if desencriptar(obt[0][1]) == self.txt_login_pass.value:
            self.page.go("/datos")
        else:
            self.show_msg(True,"Cryp-levs","Contraseña incorrecta.","error")                     

    def salir(self,e):
        pass
    def close_msg_no(self,e):            
        self.dlg_modal.open = False
        self.page.update()
    def captura_rpta(self,a):
        self.msg_rpta = a

    def show_msg(self,Simple: bool,titulo: str,cuerpo: str,Estilo: str,accion=None,modo_input=False,passw=False):    
        if Estilo == "error":
            ic = ft.icons.ERROR
            ic_color = "#fb3b2e" #Rojo
        elif Estilo == "info":
            ic = ft.icons.INFO
            ic_color = "#2e8d7d" #Verde
        elif Estilo == "warning":
            ic = ft.icons.WARNING
            ic_color = "#f2b746" #Naranja     
    
        if Simple == True:
            self.dlg_modal = ft.AlertDialog(            
            modal=True,
            title=Row(
                controls=[
                    Icon(name=ic,color=ic_color,size=35),
                    Text(titulo,size=22,weight=ft.FontWeight.W_600,color="white")
                    ]
            ),
            content=Text(cuerpo,size=18,weight=ft.FontWeight.W_500,color="white"),
            actions=[              
                ElevatedButton(content=Text("Aceptar",size=18),width= 120,bgcolor="#2e8d7d",color="white",on_click=self.close_msg_no),               
            ],
            actions_alignment=ft.MainAxisAlignment.END            
            )
        else:
            if modo_input == False:
                xcuerpo = Text(cuerpo,size=18,weight=ft.FontWeight.W_500,color="white")
                btn1,btn2 = "Si","No"
                btn_w = 80
            else:
                btn_w = 120
                btn1,btn2 = "Aceptar","Cancelar"
                xcuerpo = Column(height=100,
                    controls=[
                        Text(cuerpo,size=18,weight=ft.FontWeight.W_500,color="white"),
                        TextField(value="",hint_text="Escriba su respuesta",hint_style={"size":18,"color":"#A0A0A0"},width=380,
                                text_size="18",color=lst_colores[4],border_radius=15,bgcolor=lst_colores[5],
                                border_color=lst_colores[0],height=45,
                                password=passw,can_reveal_password=passw,
                                on_change=lambda e: self.captura_rpta(e.control.value))
                    ]
                    )
            self.dlg_modal = ft.AlertDialog(            
            modal=True,
            title=Row(
                controls=[
                    Icon(name=ic,color=ic_color,size=35),
                    Text(titulo,size=22,weight=ft.FontWeight.W_600,color="white")
                    ]
            ),            
            content=xcuerpo,
            actions=[
                ElevatedButton(content=Text(btn1,size=18),width= btn_w,bgcolor="#2e8d7d",color="white",
                               on_click=accion),
                ElevatedButton(content=Text(btn2,size=18),width= btn_w,bgcolor="#2e8d7d",color="white",on_click=self.close_msg_no),               
            ],
            actions_alignment=ft.MainAxisAlignment.END,            
            )

        self.page.dialog = self.dlg_modal
        self.dlg_modal.open = True
        self.page.update()
    
    def build(self):
        return self.bg_principal