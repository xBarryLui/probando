import flet as ft
from flet import *
from form_login import Login
from form_datos import Datos

def main(page:Page):       
    page.window_center()
    page.title = "Cryp-levs"  
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    # COnfiguracion de la ventana
    page.window_height = 840
    page.window_width = 400
    ############### CONTROLADOR DE CAMBIO DE RUTAS
    def cambiar_ruta(route):
        page.views.clear()      
        if page.route =="/login":         
            page.views.append(
                ft.View(
                    vertical_alignment=ft.MainAxisAlignment.CENTER,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    bgcolor= "#1d1c28",
                    route="/login",
                    controls=[
                        #aqui agregar
                        Login(page)
                    ]
                )
            )

        if page.route =="/datos":         
            page.views.append(
                ft.View(
                    vertical_alignment=ft.MainAxisAlignment.START,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    bgcolor= "#1d1c28",
                    route="/datos",
                    controls=[
                        #aqui agregar
                        Datos(page)
                    ]
                )
            )
        page.update()

    def view_pop(view):        
        page.views.pop()
        top_view = page.views[-1]
        page.go(top_view.route)

    page.on_route_change = cambiar_ruta
    #page.on_view_pop = view_pop
    page.go("/login")
    
      
    

ft.app(target=main,assets_dir="data")