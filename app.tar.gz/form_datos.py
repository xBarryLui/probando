import flet as ft
from flet import *
from cryptography.fernet import Fernet
from sql_module import SQL_MODULE

lst_colores = ["#2e8d7d", #Verde esmeralda 0
                   "#1d1c28", #Azul oscuro     1
                   "#3a3b47", #Gris claro      2
                   "#29323d", #Verde esmeralda oscuro     3
                   "white",   #Blanco color    4
                   "black",   #Negro color     5
                   "#2e2c3f",  #Gris oscuro    6
                   "#A0A0A0"  #Blanco apagado  7
                   ]
key = b"652OQj1DO5t6LONCHO-X1jN-XgthFVg60kmy3saP7sI="
def encriptar(texto):
    fernet = Fernet(key)
    return fernet.encrypt(texto.encode())
def desencriptar(texto):
    fernet = Fernet(key)
    return fernet.decrypt(texto).decode()

class btns(UserControl):    
    def __init__(self,page,id_now,accion1,accion2,msg,close_msg_no):
        super().__init__()
        self.page = page
        self.id_now = id_now
        self.accion1 = accion1 #para actualizar
        self.accion2 = accion2 #para editar
        self.show_msg = msg
        self.close_msg_no = close_msg_no        

    def editar(self,e):       
        self.accion2(self.id_now)
          
    def eliminar_ahora(self,e):        
        self.close_msg_no(e)
        self.page.update()
        obt = SQL_MODULE.SQL_Consulta("Datos","Id","=",self.id_now,"Id","ASC")       
        SQL_MODULE.SQL_Eliminar("Datos","Id",self.id_now)        
        self.accion1("Id","%")
        self.show_msg(True,"Cryp-levs",f"Se elimino el registro: {obt[0][1]}","info")
        
        
    def eliminar(self,e):
        obt = SQL_MODULE.SQL_Consulta("Datos","Id","=",self.id_now,"Id","ASC")
        self.show_msg(False,"Cryp-levs",f"Desea eliminar el registro: {obt[0][1]}. ?","info",self.eliminar_ahora)
        
        
    def build(self):
        return Container(
                bgcolor=lst_colores[1],
                width=50,height=100,border_radius=15,
                border=border.all(width=2,color=lst_colores[3]),
                content=Column(
                    spacing=0,alignment=ft.MainAxisAlignment.CENTER,
                    controls=[
                        IconButton(icon=ft.icons.EDIT_SQUARE,icon_color=lst_colores[0],icon_size=30,tooltip="Editar",
                                on_click=self.editar),
                        IconButton(icon=ft.icons.DELETE_FOREVER,icon_color=lst_colores[0],icon_size=30,tooltip="Eliminar",
                                on_click=self.eliminar)
                    ]
                )
            )
class Datos(UserControl):
    #Variables 
    def __init__(self,page):
        super().__init__()
        self.page = page
        self.msg_rpta = ""
        self.mode = ""
        self.n_reg = ""
        self.stp = 0
        #controles
        self.btn_cancel2 = ElevatedButton(content=Text("Cancelar",size=18,color=lst_colores[4]),width= 320,
                                            bgcolor=lst_colores[2],on_click=self.cancelar)
        self.btn_sig = ElevatedButton(content=Text("Siguiente",size=18,color=lst_colores[5]),width= 320,
                                            bgcolor=lst_colores[0],on_click=self.cambiar_contra_acciones)
        self.txt_pass_login= TextField(value="",hint_text="Confirme su contraseña",hint_style={"size":18,"color":"#A0A0A0"},width=320,height=50,
                                text_size="15",color=lst_colores[4],border_radius=15,bgcolor=lst_colores[3],
                                prefix_icon=ft.icons.KEY,
                                border_color=lst_colores[0],can_reveal_password=True,password=True)
        self.btn_cancel = ElevatedButton(content=Text("Cancelar",size=18,color=lst_colores[4]),width= 150,
                                            bgcolor=lst_colores[2],on_click=self.cancelar)
        self.btn_save = ElevatedButton(content=Text("Guardar",size=18,color=lst_colores[5]),width= 150,
                                            bgcolor=lst_colores[0],on_click=self.save_modi)
        self.txt_descripcion= TextField(value="",label="Descripcion",hint_style={"size":18,"color":"#A0A0A0"},width=320,
                                text_size="15",color=lst_colores[4],border_radius=15,bgcolor=lst_colores[3],
                                border_color=lst_colores[0],max_length=80,max_lines=3,multiline=True)
        self.txt_pass= TextField(value="",label="Contraseña",hint_style={"size":18,"color":"#A0A0A0"},width=320,height=50,
                                text_size="15",color=lst_colores[4],border_radius=15,bgcolor=lst_colores[3],
                                border_color=lst_colores[0],can_reveal_password=True,password=True)
        self.txt_titulo= TextField(value="",label="Titulo",hint_style={"size":18,"color":"#A0A0A0"},width=320,
                                text_size="15",color=lst_colores[4],border_radius=15,bgcolor=lst_colores[3],
                                border_color=lst_colores[0],max_lines=2)
        self.popu_men1 = PopupMenuButton(
            tooltip="Registro",
            items=[                
                PopupMenuItem(icon=ft.icons.CREATE_NEW_FOLDER, text="Nuevo registro",on_click=self.nuevo),
                PopupMenuItem(icon=ft.icons.REFRESH, text="Actualizar registro", on_click=self.refrescar),
                PopupMenuItem(),
                PopupMenuItem(icon=ft.icons.SECURITY, text="Cambiar contraseña", on_click=self.cambiar_contra),
                
            ]
        ) 
        self.lbl_cnt_total = Text("0 registros",size=15,weight=ft.FontWeight.W_400,color="white")
        self.txt_busqueda = TextField(value="",hint_text="Busqueda",hint_style={"size":15,"color":"#A0A0A0"},width=270,
                                text_size="15",color=lst_colores[4],bgcolor="transparent",
                                border="none",prefix_icon=ft.icons.SEARCH,height=45,on_change=self.buscar)
        self.bg_datos = Container(
            bgcolor=lst_colores[1],
            width=320,height=430  
        )
        self.bar_controls = Container(
            bgcolor=lst_colores[3],
            width=320,height=45,border_radius=15,
            border=border.all(width=2,color=lst_colores[0]),
            content= Row(
                spacing=0,alignment=ft.MainAxisAlignment.START,
                controls=[
                    VerticalDivider(color="transparent",width=5),
                    self.txt_busqueda,
                    VerticalDivider(color=lst_colores[2],width=5),
                    self.popu_men1
                    
                ]
            )
        )
    def cambiar_contra_acciones(self,e):
        if self.stp == 0:
            obt = SQL_MODULE.SQL_Consulta("Aux","Id","=","1","Id","ASC")
            if self.txt_pass_login.value == desencriptar(obt[0][1]):
                self.stp +=1
                self.btn_sig.content.value = "Cambiar" 
                self.btn_sig.update()
                self.txt_pass_login.hint_text = "Escriba la nueva contraseña"
                self.txt_pass_login.value = ""
                self.txt_pass_login.update()
            else:
                self.show_msg(True,"Cryp-levs","Contraseña incorrecta.","error")
        elif self.stp == 1:
            if self.txt_pass_login.value == "":
                self.show_msg(True,"Cryp-levs","Ingrese una contraseña válida.","error")
            else:
                SQL_MODULE.SQL_Modificar("Aux",["Pass"],[encriptar(self.txt_pass_login.value).decode()],"Id","1")
                self.show_msg(True,"Cryp-levs","Se establecio una nueva contraseña de acceso.","info")
                self.cancelar(e)


    def cambiar_contra(self,e):        
        self.txt_busqueda.disabled = True        
        self.popu_men1.disabled = True
        self.bar_controls.update()
        self.lbl_cnt_total.visible = False
        self.lbl_cnt_total.update()
        self.bg_datos.clean()
        #limpiamos controles
        self.stp = 0
        self.txt_pass_login.value = ""
        self.btn_sig.content.value = "Siguiente" 
        self.txt_pass_login.hint_text = "Confirme su contraseña"
                
        self.bg_datos.content = Column(
            controls=[
                Row( 
                    controls=[
                        Icon(name=ft.icons.SECURITY,size=30,color=lst_colores[4]),
                        Text(f"Cambiar contraseña de acceso",size=18,weight=ft.FontWeight.W_400,color=lst_colores[4])                        
                    ]
                ),Divider(color=lst_colores[0],height=10),
                self.txt_pass_login,
                Divider(color="transparent",height=10),
                self.btn_sig,self.btn_cancel2
                
            ]
        )
        self.bg_datos.update()

    def save_modi(self,e):
        if self.mode == "new":
            #guardamos
            if self.txt_titulo.value == "" or self.txt_pass.value == "" or self.txt_descripcion.value == "":
                self.show_msg(True,"Cryp-levs","Los campos no pueden quedar vacios.","warning")
            else:
                cols_name = ["Id","Titulo","Pass","Descripcion"]                              
                cols_values = [self.n_reg,self.txt_titulo.value,encriptar(self.txt_pass.value).decode(),encriptar(self.txt_descripcion.value).decode()]
                SQL_MODULE.SQL_Nuevo("Datos",cols_name,cols_values)
                SQL_MODULE.SQL_Modificar("Aux",["datos"],[self.n_reg],"Id","1")
                self.cancelar(e)
                self.show_msg(True,"Cryp-levs","Se agrego un nuevo registro.","info")
        else:
            #editamos
            if self.txt_titulo.value == "" or self.txt_pass.value == "" or self.txt_descripcion.value == "":
                self.show_msg(True,"Cryp-levs","Los campos no pueden quedar vacios.","warning")
            else:
                cols_name = ["Id","Titulo","Pass","Descripcion"]                              
                cols_values = [self.n_reg,self.txt_titulo.value,encriptar(self.txt_pass.value).decode(),encriptar(self.txt_descripcion.value).decode()]
                
                SQL_MODULE.SQL_Modificar("Datos",cols_name,cols_values,"Id",self.n_reg)
                self.cancelar(e)
                self.show_msg(True,"Cryp-levs","Se modificó el registro seleccionado.","info")
    
    def cancelar(self,e):
        self.txt_busqueda.disabled = False       
        self.popu_men1.disabled = False
        self.bar_controls.update()
        self.lbl_cnt_total.visible = True
        self.lbl_cnt_total.update()
        self.cargar_datos("Id","%")
    def nuevo(self,e):
        self.mode = "new"
        self.txt_busqueda.disabled = True        
        self.popu_men1.disabled = True
        self.bar_controls.update()
        self.lbl_cnt_total.visible = False
        self.lbl_cnt_total.update()
        self.bg_datos.clean()
        #limpiamos controles
        self.txt_titulo.value =""
        self.txt_pass.value = ""
        self.txt_descripcion.value = ""
        self.btn_save.content.value = "Guardar"
        obt = SQL_MODULE.SQL_Consulta("Aux","Id","=","1","Id","ASC") 
        self.n_reg = int(obt[0][2]) + 1
        self.bg_datos.content = Column(
            controls=[
                Row( 
                    controls=[
                        Icon(name=ft.icons.CREATE_NEW_FOLDER,size=30,color=lst_colores[4]),
                        Text(f"|{self.n_reg}| Nuevo registro",size=18,weight=ft.FontWeight.W_400,color=lst_colores[4])                        
                    ]
                ),Divider(color=lst_colores[0],height=10),
                self.txt_titulo,self.txt_pass,self.txt_descripcion,
                Divider(color="transparent",height=10),
                Row(
                    alignment=ft.MainAxisAlignment.CENTER,
                    controls=[
                        self.btn_save,self.btn_cancel
                    ]
                )
            ]
        )
        self.bg_datos.update()
    def buscar(self,e):
        self.cargar_datos("Titulo",f"%{self.txt_busqueda.value}%") 
    def editar(self,id_reg):
        self.n_reg = id_reg
        self.mode = "edit"
        self.txt_busqueda.disabled = True        
        self.popu_men1.disabled = True
        self.bar_controls.update()
        self.lbl_cnt_total.visible = False
        self.lbl_cnt_total.update()
        self.bg_datos.clean()
        #limpiamos controles
        obt = SQL_MODULE.SQL_Consulta("Datos","Id","=",id_reg,"Id","ASC") 
        self.txt_titulo.value =obt[0][1]
        self.txt_pass.value = desencriptar(obt[0][2])
        self.txt_descripcion.value = desencriptar(obt[0][3])
        self.btn_save.content.value = "Modificar"       
                
        self.bg_datos.content = Column(
            controls=[
                Row( 
                    controls=[
                        Icon(name=ft.icons.CREATE_NEW_FOLDER,size=30,color=lst_colores[4]),
                        Text(f"|{id_reg}| Editar registro",size=18,weight=ft.FontWeight.W_400,color=lst_colores[4])                        
                    ]
                ),Divider(color=lst_colores[0],height=10),
                self.txt_titulo,self.txt_pass,self.txt_descripcion,
                Divider(color="transparent",height=10),
                Row(
                    alignment=ft.MainAxisAlignment.CENTER,
                    controls=[
                        self.btn_save,self.btn_cancel
                    ]
                )
            ]
        )
        self.bg_datos.update()
    
    def refrescar(self,e):
        self.cargar_datos("Id","%")
    def cargar_datos(self,inCol,buscar):
        self.bg_datos.clean()
        cont_data= ListView(expand=1, spacing=10, padding=0, auto_scroll=False)
        self.bg_datos.content = cont_data
        data = SQL_MODULE.SQL_Consulta("Datos",inCol,"LIKE",buscar,"Id","ASC") 
        total_reg = len(data)     
        for i in range(len(data)):
            contra = desencriptar(data[i][2])
            descripc =desencriptar(data[i][3])
            inf_data = Column(
                alignment=ft.MainAxisAlignment.START,
                horizontal_alignment= ft.CrossAxisAlignment.START,expand=True,
                controls= [
                    Divider(color="transparent",height=5),
                    Row(
                    controls=[
                        VerticalDivider(color="transparent",width=5),                        
                        Text(f"{data[i][1]}",size=15,weight=ft.FontWeight.W_400,color=lst_colores[4],width=310,max_lines=2),                      
                        #Exp_btns(self.page,data[i][0],self.show_expedientes,self.show_msg,self.close_msg_no,self.registrar_actividad)
                    ]                    
                    ),
                    Divider(color=lst_colores[2],height=1),
                    Row(
                    controls=[
                        VerticalDivider(color="transparent",width=5),
                        Icon(name=ft.icons.KEY,size=20,color=lst_colores[0]),                    
                        Text(f"Contraseña: {contra}",size=15,weight=ft.FontWeight.W_400,color=lst_colores[4])                        
                    ]                    
                    ),
                    Row(
                    controls=[
                        VerticalDivider(color="transparent",width=5),
                        Icon(name=ft.icons.SPEAKER_NOTES,size=20,color=lst_colores[0]),                    
                        Text(f"Descripción:\n{descripc}",size=15,weight=ft.FontWeight.W_400,color=lst_colores[4],width=200,max_lines=4),
                        btns(self.page,data[i][0],self.cargar_datos,self.editar,self.show_msg,self.close_msg_no)            
                    ]                    
                    ),
                ]
            )
            cont_data.controls.append(
                Row(
                alignment=ft.MainAxisAlignment.CENTER,expand=True,
                controls= [
                    Container(
                        bgcolor=lst_colores[3],            
                        height= 220,
                        width= 320,
                        border_radius=15,
                        border=border.all(width=2,color=lst_colores[0]),
                        content= inf_data
                    )                
                ]
            )
             )
            cont_data.controls.append(Divider(color="transparent",height=5))
        if total_reg == 0:
            texto_inf = f"0 registros"
        elif total_reg == 1:
            texto_inf = f"1 registro"
        else:
            texto_inf = f"{total_reg} registros"
        self.lbl_cnt_total.value = texto_inf
        self.lbl_cnt_total.update()
        self.bg_datos.update()
      
    def close_msg_no(self,e):            
        self.dlg_modal.open = False
        self.page.update()
    def captura_rpta(self,a):
        self.msg_rpta = a

    def show_msg(self,Simple: bool,titulo: str,cuerpo: str,Estilo: str,accion=None,modo_input=False,passw=False):    
        if Estilo == "error":
            ic = ft.icons.ERROR
            ic_color = "#fb3b2e" #Rojo
        elif Estilo == "info":
            ic = ft.icons.INFO
            ic_color = "#2e8d7d" #Verde
        elif Estilo == "warning":
            ic = ft.icons.WARNING
            ic_color = "#f2b746" #Naranja     
    
        if Simple == True:
            self.dlg_modal = ft.AlertDialog(            
            modal=True,
            title=Row(
                controls=[
                    Icon(name=ic,color=ic_color,size=35),
                    Text(titulo,size=22,weight=ft.FontWeight.W_600,color="white")
                    ]
            ),
            content=Text(cuerpo,size=18,weight=ft.FontWeight.W_500,color="white"),
            actions=[              
                ElevatedButton(content=Text("Aceptar",size=18),width= 120,bgcolor="#2e8d7d",color="white",on_click=self.close_msg_no),               
            ],
            actions_alignment=ft.MainAxisAlignment.END            
            )
        else:
            if modo_input == False:
                xcuerpo = Text(cuerpo,size=18,weight=ft.FontWeight.W_500,color="white")
                btn1,btn2 = "Si","No"
                btn_w = 80
            else:
                btn_w = 120
                btn1,btn2 = "Aceptar","Cancelar"
                xcuerpo = Column(height=100,
                    controls=[
                        Text(cuerpo,size=18,weight=ft.FontWeight.W_500,color="white"),
                        TextField(value="",hint_text="Escriba su respuesta",hint_style={"size":18,"color":"#A0A0A0"},width=380,
                                text_size="18",color=lst_colores[4],border_radius=15,bgcolor=lst_colores[5],
                                border_color=lst_colores[0],height=45,
                                password=passw,can_reveal_password=passw,
                                on_change=lambda e: self.captura_rpta(e.control.value))
                    ]
                    )
            self.dlg_modal = ft.AlertDialog(            
            modal=True,
            title=Row(
                controls=[
                    Icon(name=ic,color=ic_color,size=35),
                    Text(titulo,size=22,weight=ft.FontWeight.W_600,color="white")
                    ]
            ),            
            content=xcuerpo,
            actions=[
                ElevatedButton(content=Text(btn1,size=18),width= btn_w,bgcolor="#2e8d7d",color="white",
                               on_click=accion),
                ElevatedButton(content=Text(btn2,size=18),width= btn_w,bgcolor="#2e8d7d",color="white",on_click=self.close_msg_no),               
            ],
            actions_alignment=ft.MainAxisAlignment.END,            
            )

        self.page.dialog = self.dlg_modal
        self.dlg_modal.open = True
        self.page.update()
    def did_mount(self):        
        self.cargar_datos("Id","%")

    def build(self):
        return SafeArea(            
            Container(
                #Contenedor madre
                bgcolor= lst_colores[1],            
                height= 700,
                width= 500,                        
                border_radius=10,
                border=border.all(width=5,color=lst_colores[0]),
                content= Column(
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,                    
                    spacing=0,
                    controls=[
                        Divider(color="transparent",height=15),
                        Text("Cryp-levs",size=35,weight=ft.FontWeight.W_400,color=lst_colores[0]),
                        Divider(color="transparent",height=15),
                        Text("Administre el registro de su informacion personal de forma segura",size=15,weight=ft.FontWeight.W_400,color="white",
                             width=320,height=45),
                        Divider(color="transparent",height=10),
                        self.bar_controls,Divider(color=lst_colores[0],height=25),
                        Row(
                            alignment=ft.MainAxisAlignment.END,
                            controls=[
                                self.lbl_cnt_total,VerticalDivider(color="transparent",width=15)
                            ]
                        ),Divider(color="transparent",height=10),
                        self.bg_datos
                
                    ]
                )
                
        )
        )