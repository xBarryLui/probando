import mysql.connector
host = 'monorail.proxy.rlwy.net'
user = 'root'
password = '-hfe3Bd6D-2hH2AfBch-2Dc3C25BcFFh'
database = 'railway'
port = "23560"

class SQL_MODULE():
    def con():
        conex = mysql.connector.connect(host=host, user=user, password=password, database=database,port=port)
        conex.close()
        return conex
    def SQL_Eliminar(tabla,InCol,ValCol):
        inst1 = f"""
            DELETE FROM {tabla} WHERE {InCol} = {ValCol} 
            """
        conex = mysql.connector.connect(host=host, user=user, password=password, database=database,port=port)
        cursor = conex.cursor()
        cursor.execute(inst1)
        Obtenido = cursor.fetchall()    
        conex.commit()
        conex.close()    

    def SQL_Nuevo(tabla,colsName,colsValues):
        Colss = ""
        Valcolss = ""
        for i in range(len(colsName)):
            Colss += colsName[i]  + ","
            Valcolss += "'" + str(colsValues[i])+ "'" + ","
        Colss = Colss[0:len(Colss)-1]
        Valcolss = Valcolss[0:len(Valcolss)-1]   
        inst1 = f"INSERT INTO {tabla} ({Colss}) VALUES ({Valcolss})"        
        conex = mysql.connector.connect(host=host, user=user, password=password, database=database,port=port)
        cursor = conex.cursor()
        cursor.execute(inst1)        
        conex.commit()
        conex.close() 

    def SQL_Modificar(tabla,colsName,colsValues,KeyName,KeyValue):
        jointt = ""
        for i in range(len(colsName)):
            jointt += colsName[i] + "=" + "'" + str(colsValues[i]) + "'" + ","
        jointt = jointt[0:len(jointt)-1]    
        inst1 = f"""
            UPDATE {tabla} SET {jointt} WHERE {KeyName} = "{KeyValue}"
            """
        conex = mysql.connector.connect(host=host, user=user, password=password, database=database,port=port)
        cursor = conex.cursor()
        cursor.execute(inst1)        
        conex.commit()
        conex.close()     

    def SQL_Consulta(tabla,InCol,Operador,Word,ColOrder,Asc):
        inst1 = f"""
            SELECT* FROM {tabla} WHERE {InCol} {Operador} "{Word}" ORDER BY {ColOrder} {Asc}
            """
        conex = mysql.connector.connect(host=host, user=user, password=password, database=database,port=port)
        cursor = conex.cursor()
        cursor.execute(inst1)
        Obtenido = cursor.fetchall()
        conex.close()
        return Obtenido